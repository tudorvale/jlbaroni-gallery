(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__3348b948._.css",
  "static/chunks/node_modules_5b95bb50._.js",
  "static/chunks/src_56f06ab8._.js"
],
    source: "dynamic"
});
