(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_15251bc2._.js",
  "static/chunks/src_components_ProtectedImage_tsx_1197773a._.js"
],
    source: "dynamic"
});
